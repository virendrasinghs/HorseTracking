using Xunit;

namespace HorseTrack.Services.Tests
{
    
    public class CommandServiceTests
    {
        private readonly CommandService commandService;


        public CommandServiceTests()
        {
            commandService = new CommandService();
        }

        [Fact(DisplayName = "TestParseCommandWinner")]
        public void TestParseCommandWinner()
        {
            string commandString = "W 5";
            string expected = "winner";
            string actual = commandService.parseCommand(commandString);
            Assert.Equal(expected, actual);
        }

        [Fact(DisplayName = "TestParseCommandWager_Success")]
        public void TestParseCommandWager_Success()
        {
            string commandString = "1 55";
            string expected = "wager";
            string actual = commandService.parseCommand(commandString);
            Assert.Equal(expected, actual);
        }


        [Fact(DisplayName = "TestParseCommandWager_Error")]
        public void TestParseCommandWager_Error()
        {
            string commandString = "1 5.9";
            string expected = "error";
            string actual = commandService.parseCommand(commandString);
            Assert.Equal(expected, actual);
        }

        [Fact(DisplayName = "TestParseCommandQuit")]
        public void TestParseCommandQuit()
        {
            string commandString = "q";
            string expected = "quit";
            string actual = commandService.parseCommand(commandString);
            Assert.Equal(expected, actual);
        }

        [Fact(DisplayName = "TestParseCommandRestock")]
        public void TestParseCommandRestock()
        {
            string commandString = "R";
            string expected = "restock";
            string actual = commandService.parseCommand(commandString);
            Assert.Equal(expected, actual);
        }


        [Fact(DisplayName = "TestParseCommandInvalid")]
        public void TestParseCommandInvalid()
        {
            string commandString = "X";
            string expected = "invalid";
            string actual = commandService.parseCommand(commandString);
            Assert.Equal(expected, actual);
        }

    }
}
