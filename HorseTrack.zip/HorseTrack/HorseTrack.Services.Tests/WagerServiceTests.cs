﻿using HorseTrack.Services.Interfaces;
using Moq;
using Xunit;

namespace HorseTrack.Services.Tests
{
    public class WagerServiceTests
    {
        private readonly WagerService  wagerService;
        private readonly Mock<IInventoryService> _mockInventoryService = new Mock<IInventoryService>();

        public WagerServiceTests()
        {
            wagerService = new WagerService(_mockInventoryService.Object);
        }

        [Fact(DisplayName = "TestCalculateAmountWon")]
        public void TestCalculateAmountWon()
        {
            int wagerAmount = 55;
            int odds = 5;
            int expected = 275;
            int actual = wagerService.calculateAmountWon(wagerAmount, odds);

            Assert.Equal(expected, actual);
        }

    }
}
