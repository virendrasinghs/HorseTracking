﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack
{
    public static class Constant
    {
        // Messages
        public const String messageInventory= "Inventory";
        public const String messageHorses= "Horses";
        public const String messageNoPayout= "No Payout";
        public const String messagePayout= "Payout";
        public const String messageDispensing= "Dispensing";

        // Error Messages
        public const String errorMessageInsufficientFunds= "Insufficient Funds";
        public const String errorMessageInvalidBet= "Invalid Bet";
        public const String errorMessageInvalidCommand= "Invalid Command";
        public const String errorMessageInvalidHorseNumber= "Invalid Horse Number";


        public const int restockAmount = 10;
        private const int maxHorses = 7;
        public const String currencySymbol = "$";
    }
}
