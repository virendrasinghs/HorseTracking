﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.DataBusiness.Interfaces
{
    public interface IMainDataBusiness
    {
        public void execute(String commandLine);
        public void commandFactory(String commandLine);
        void restock();
        void wager(int horseNumber, int wagerAmount);
        void winner(int horseNumber);
        void printStartupMessages();
        void initialize();
        Boolean quit();
    }
}
