﻿using Dapper;
using HorseTrack.Database.Interfaces;
using HorseTrack.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SQLite;
using System.Linq;
using System.Text;

namespace HorseTrack.Database
{
    public class HorseTrackDatabase: IHorseTrackDatabase
    {
        public bool TruncateHorse()
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SQLiteConnection(connectionString);
                string query = @"CREATE TABLE IF NOT EXISTS Horse ([id] INTEGER PRIMARY KEY AUTOINCREMENT,[horseNumber] [int] NULL,[horseName] [nvarchar](250) NULL,[odds] [int] NULL,[raceStatus] [nvarchar](50) NULL)";
                //query = @"DROP TABLE [Horse]";
                var result = connection.Execute(query);

                query = @"DELETE FROM Horse";
                result = connection.Execute(query);

                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public bool TruncateInventory()
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SQLiteConnection(connectionString);
                string query = @"CREATE TABLE IF NOT EXISTS [Inventory]([id] INTEGER PRIMARY KEY AUTOINCREMENT,[denomination] [int] NULL,[billCount] [int] NULL)";
                //query = @"DROP TABLE [Inventory]";
                var result = connection.Execute(query);

                query = @"DELETE FROM Inventory";
                result = connection.Execute(query);

                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public bool InsertHorse(Horse horse)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SQLiteConnection(connectionString);
                string query = @"INSERT INTO Horse(horseNumber, horseName, odds, raceStatus) VALUES(@horseNumber, @horseName, @odds, @raceStatus)";
                var result = connection.Execute(query, new { @horseNumber = horse.getHorseNumber(), @horseName = horse.getHorseName(), @odds = horse.getOdds(), @raceStatus = horse.getRaceStatus().ToString() });
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Horse findByHorseNumberEquals(int horseNumber)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SQLiteConnection(connectionString);
                string query = @"Select id,horseNumber, horseName, odds, raceStatus from Horse Where horseNumber=@horseNumber ";
                return connection.QueryFirst<Horse>(query, new { @horseNumber=horseNumber });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<Horse> findAllHorse()
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SQLiteConnection(connectionString);
                string query = @"Select id,horseNumber, horseName, odds, raceStatus from Horse ";
                return connection.Query<Horse>(query).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public Boolean UpdateHorseRaceStatus(int horseNumber,string raceStatus)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SQLiteConnection(connectionString);
                string query = @"Update Horse Set raceStatus=@raceStatus where horseNumber=@horseNumber";
                connection.Execute(query, new { @raceStatus = raceStatus, @horseNumber= horseNumber });
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public List<Inventory> findAllInventory()
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SQLiteConnection(connectionString);
                string query = @"Select id,denomination,billCount from Inventory ";
                var result= connection.Query<Inventory>(query).ToList();
                return result;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public Inventory findByDenominationEquals(int denomination)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SQLiteConnection(connectionString);
                string query = @"Select id,denomination,billCount from Inventory Where denomination=@denomination ";
                return connection.QueryFirst<Inventory>(query, new { @denomination = denomination });
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public bool InsertInventory(Inventory inventory)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SQLiteConnection(connectionString);
                string query = @"INSERT INTO Inventory(denomination,billCount) VALUES(@denomination,@billCount)";
                var result = connection.Execute(query, new { @denomination = inventory.getDenomination(), @billCount=inventory.getBillCount() });
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public bool InventoryUpdate(int id, int billCount)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SQLiteConnection(connectionString);
                string query = @"Update Inventory Set billCount=@billCount where id=@id";
                connection.Execute(query, new { @billCount = billCount, @id = id });
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

    }
}
