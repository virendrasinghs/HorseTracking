﻿using HorseTrack.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Repository.Interfaces
{
    public interface IHorseRepository
    {
        bool save(Horse horse);
        Horse findByHorseNumberEquals(int horseNumber);
        List<Horse> findAll();
        Boolean UpdateHorseRaceStatus(int horseNumber, string raceStatus);
    }
}
