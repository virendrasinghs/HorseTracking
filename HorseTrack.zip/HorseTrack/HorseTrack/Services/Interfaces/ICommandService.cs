﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Services.Interfaces
{
    public interface ICommandService
    {
        void execute(String[] command);
        String parseCommand(String commandLine);
        String getCurrentCommand();
        int getBetHorseNumber();
        String getErrorMessage();
        int getWagerAmount();
        int getWinningHorseNumber();
    }
}
