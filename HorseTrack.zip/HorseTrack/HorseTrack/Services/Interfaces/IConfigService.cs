﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Services.Interfaces
{
    public interface IConfigService
    {
        void loadHorses();
        void loadInventory();
        public void Initilize();
    }
}
