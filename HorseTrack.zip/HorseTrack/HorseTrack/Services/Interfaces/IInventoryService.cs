﻿using HorseTrack.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Services.Interfaces
{
    public interface IInventoryService
    {
        void restock();
        void decrementInventory(int denomination, int amount);
        Boolean sufficientFunds(int amountWon);
        List<Inventory> getInventory();
        Inventory getInventory(int denomination);
    }
}
