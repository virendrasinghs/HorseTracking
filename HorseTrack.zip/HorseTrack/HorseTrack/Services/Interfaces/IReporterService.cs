﻿using HorseTrack.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Services.Interfaces
{
    public interface IReporterService
    {
        void printHorses();
        void printInventory();
        void printInvalidCommand(String command);
        void printInvalidHorse(int horseNumber);
        void printInvalidBet(String invalidBet);
        void printPayout(String horseName, int amountWon);
        void printNoPayout(String horseName);
        void printInsufficientFunds(int amountWon);
        void printDispense(List<Wager> dispense);
        void printErrorMessage(String message);
        void startup();
    }
}
