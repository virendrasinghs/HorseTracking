﻿using Dapper;
using HorseTrack.Database.Interfaces;
using HorseTrack.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace HorseTrack.Database
{
    public class HorseTrackDatabase: IHorseTrackDatabase
    {
        public bool TruncateHorse()
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SqlConnection(connectionString);
                string query = @"TRUNCATE TABLE Horse";
                var result = connection.Execute(query);
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public bool TruncateInventory()
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SqlConnection(connectionString);
                string query = @"TRUNCATE TABLE Inventory";
                var result = connection.Execute(query);
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public bool InsertHorse(Horse horse)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SqlConnection(connectionString);
                string query = @"INSERT INTO Horse(horseNumber, horseName, odds, raceStatus) VALUES(@horseNumber, @horseName, @odds, @raceStatus)";
                var result = connection.Execute(query, new { @horseNumber = horse.getHorseNumber(), @horseName = horse.getHorseName(), @odds = horse.getOdds(), @raceStatus = horse.getRaceStatus().ToString() });
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Horse findByHorseNumberEquals(int horseNumber)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SqlConnection(connectionString);
                string query = @"Select horseNumber, horseName, odds, raceStatus from Horse Where horseNumber=@horseNumber ";
                return connection.QueryFirst<Horse>(query, new { @horseNumber=horseNumber });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<Horse> findAllHorse()
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SqlConnection(connectionString);
                string query = @"Select horseNumber, horseName, odds, raceStatus from Horse ";
                return connection.Query<Horse>(query).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public Boolean UpdateHorseRaceStatus(int horseNumber,string raceStatus)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SqlConnection(connectionString);
                string query = @"Update Horse Set raceStatus=@raceStatus where horseNumber=@horseNumber";
                connection.Execute(query, new { @raceStatus = raceStatus, @horseNumber= horseNumber });
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public List<Inventory> findAllInventory()
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SqlConnection(connectionString);
                string query = @"Select denomination,billCount from Inventory ";
                var result= connection.Query<Inventory>(query).ToList();
                return result;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public Inventory findByDenominationEquals(int denomination)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SqlConnection(connectionString);
                string query = @"Select denomination,billCount from Inventory Where denomination=@denomination ";
                return connection.QueryFirst<Inventory>(query, new { @denomination = denomination });
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public bool InsertInventory(Inventory inventory)
        {
            try
            {

                // SQL Server
                var connectionString = ConfigurationManager.AppSettings["ConnectionString"];
                using var connection = new SqlConnection(connectionString);
                string query = @"INSERT INTO Inventory(denomination,billCount) VALUES(@denomination,@billCount)";
                var result = connection.Execute(query, new { @denomination = inventory.getDenomination(), @billCount=inventory.getBillCount() });
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
