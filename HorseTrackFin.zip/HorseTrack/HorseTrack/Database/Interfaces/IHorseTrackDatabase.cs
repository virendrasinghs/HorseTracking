﻿using HorseTrack.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Database.Interfaces
{
    public interface IHorseTrackDatabase
    {
        bool InsertHorse(Horse horse);
        Horse findByHorseNumberEquals(int horseNumber);
        List<Horse> findAllHorse();
        Boolean UpdateHorseRaceStatus(int horseNumber, string raceStatus);
        List<Inventory> findAllInventory();
        Inventory findByDenominationEquals(int denomination);
        bool InsertInventory(Inventory inventory);
        bool TruncateInventory();
        bool TruncateHorse();
    }
}
