﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Model
{
    public class Inventory
    {

        public Inventory()
        {
        }

        public Inventory(int denomination, int billCount)
        {
            this.denomination = denomination;
            this.billCount = billCount;
        }

        private int id;
        private int denomination;

        private int billCount;

        public int getId()
        {
            return id;
        }

        public void setId(int id)
        {
            this.id = id;
        }

        public int getDenomination()
        {
            return denomination;
        }

        public void setDenomination(int denomination)
        {
            this.denomination = denomination;
        }

        public int getBillCount()
        {
            return billCount;
        }

        public void setBillCount(int billCount)
        {
            this.billCount = billCount;
        }

        public String toString()
        {
            StringBuilder sb = new StringBuilder("Inventory{");
            sb.Append("id=").Append(id);
            sb.Append(", denomination=").Append(denomination);
            sb.Append(", billCount=").Append(billCount);
            sb.Append('}');
            return sb.ToString();
        }
    }

}
