﻿using HorseTrack.DataBusiness;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using StructureMap;
using HorseTrack.DataBusiness.Interfaces;
using HorseTrack.Services;
using HorseTrack.Services.Interfaces;
using HorseTrack.Database.Interfaces;
using HorseTrack.Database;
using HorseTrack.Repository.Interfaces;
using HorseTrack.Repository;

namespace HorseTrack
{
    public class Program
    {
        public Program()
        {
        }

        static void Main(string[] args)
        {

            //add the framework services
            var collection = new ServiceCollection();

            collection.AddScoped<IMainDataBusiness, MainDataBusiness>();
            collection.AddScoped<ICommandService, CommandService>();
            collection.AddScoped<IConfigService, ConfigService>();
            collection.AddScoped<IHorseService, HorseService>();
            collection.AddScoped<IInventoryService, InventoryService>();
            collection.AddScoped<IReporterService, ReporterService>();
            collection.AddScoped<IWagerService, WagerService>();
            collection.AddScoped<IHorseTrackDatabase, HorseTrackDatabase>();
            collection.AddScoped<IHorseRepository, HorseRepository>();
            collection.AddScoped<IInventoryRepository, InventoryRepository>();

            //add structuremp
            var container = new Container();
            container.Configure(config =>
            {
                // Register stuff in container, using the StructureMap APIs...
                config.Scan(_ =>
                {
                    _.AssemblyContainingType(typeof(Program));
                    _.WithDefaultConventions();
                });
            });

            IServiceProvider serviceProvider = collection.BuildServiceProvider();
            var mainDataBusiness = serviceProvider.GetService<IMainDataBusiness>();
            mainDataBusiness.initialize();
            mainDataBusiness.printStartupMessages();

            while (!(mainDataBusiness.quit()))
            {

                // Read from the command line
                // validate the input
                mainDataBusiness.execute(Console.ReadLine());

            }

            if (serviceProvider is IDisposable)
            {
                ((IDisposable)serviceProvider).Dispose();
            }

            // Wait for the user to respond before closing.
            //Console.Write("Press any key to close the Calculator console app...");
            //Console.ReadKey();
            //var serviceProvider = container.GetInstance<IServiceProvider>();

            ////configure console logging
            //serviceProvider
            //    .GetService<ILoggerFactory>();

            //var logger = serviceProvider.GetService<ILoggerFactory>()
            //    .CreateLogger<Program>();

            //logger.LogDebug("Starting application");


        }
        

    }
}
