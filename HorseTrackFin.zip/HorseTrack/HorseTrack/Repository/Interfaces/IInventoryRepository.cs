﻿using HorseTrack.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Repository.Interfaces
{
    public interface IInventoryRepository
    {
        bool save(Inventory inventory);
        Inventory findByDenominationEquals(int denomination);
        List<Inventory> findAll();
    }
}
