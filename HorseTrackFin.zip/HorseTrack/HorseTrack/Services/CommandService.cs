﻿using HorseTrack.Services.Interfaces;
using System;
using System.Text.RegularExpressions;

namespace HorseTrack.Services
{

    public class CommandService: ICommandService
    {
        private int betHorseNumber;
        private String currentCommand;
        private int wagerAmount;
        private int winningHorseNumber;
        private String errorMessage;

        public CommandService()
        {
        }
        public void execute(String[] command)
        {
        }

        public String parseCommand(String commandLine)
        {

            // Split the command line into its component parts
            String[] commandComponents = commandLine.Split(" ");
            string strWinRegex = @"[W,w] [1-9]";
            string strWagerRegex = @"[0-9]+ [0-9]+.?[0-9]*";
            Regex winre = new Regex(strWinRegex);
            Regex wagere = new Regex(strWagerRegex);

            if (commandComponents[0].Equals("q", StringComparison.OrdinalIgnoreCase))
            {
                currentCommand = "quit";
                return currentCommand;
            }
            else if (commandComponents[0].Equals("r", StringComparison.OrdinalIgnoreCase))
            {
                currentCommand = "restock";
                return currentCommand;
            }
            else if (winre.IsMatch(commandLine))
            {
                winningHorseNumber = Convert.ToInt32(commandComponents[1]);
                currentCommand = "winner";
                return currentCommand;
            }
            else if (wagere.IsMatch(commandLine))
            {
                betHorseNumber = Convert.ToInt32(commandComponents[0]);
                try
                {
                    wagerAmount = Convert.ToInt32(commandComponents[1]);
                }
                catch (FormatException e)
                {
                    errorMessage = Constant.errorMessageInvalidBet + " " + commandComponents[1];
                    currentCommand = "error";
                    return currentCommand;
                }
                catch (Exception ex) 
                {
                    errorMessage = Constant.errorMessageInvalidBet + " " + commandComponents[1];
                    currentCommand = "error";
                    return currentCommand;
                }  
                currentCommand = "wager";
                return currentCommand;
            }
            else
            {
                currentCommand = "invalid";
                return currentCommand;
            }
        }

        public String getCurrentCommand()
        {
            return currentCommand;
        }

        public int getBetHorseNumber()
        {
            return betHorseNumber;
        }

        public String getErrorMessage()
        {
            return errorMessage;
        }

        public int getWagerAmount()
        {
            return wagerAmount;
        }

        public int getWinningHorseNumber()
        {
            return winningHorseNumber;
        }

    }
}
