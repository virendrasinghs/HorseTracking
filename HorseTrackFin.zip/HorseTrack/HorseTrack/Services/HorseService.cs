﻿using HorseTrack.Enum;
using HorseTrack.Model;
using HorseTrack.Repository;
using HorseTrack.Repository.Interfaces;
using HorseTrack.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HorseTrack.Services
{
    public class HorseService: IHorseService
    {
        private IHorseRepository horseRepository;

        public HorseService(IHorseRepository _horseRepository)
        {
            horseRepository = _horseRepository;
        }

        public String getHorseName(int horseNumber)
        {
            Horse horse = horseRepository.findByHorseNumberEquals(horseNumber);

            return horse.getHorseName();
        }

        public int getHorseOdds(int horseNumber)
        {
            Horse horse = horseRepository.findByHorseNumberEquals(horseNumber);

            return horse.getOdds();
        }

        public Boolean isHorseWinner(int horseNumber)
        {
            Horse horse = horseRepository.findByHorseNumberEquals(horseNumber);
            if (horse.getRaceStatus() == RaceStatus.WON)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public Boolean isValidHorseNumber(int horseNumber)
        {
            if (horseRepository.findByHorseNumberEquals(horseNumber) == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public void setRaceWinner(int horseNumber)
        {

            List<Horse> horses = horseRepository.findAll();
            var WinHorses = horses.Where(h => h.getRaceStatus() == RaceStatus.WON).ToList();
            foreach (var losingHorse in WinHorses)
            {
                horseRepository.UpdateHorseRaceStatus(losingHorse.getHorseNumber(), RaceStatus.LOST.ToString());
            }

            horseRepository.UpdateHorseRaceStatus(horseNumber, RaceStatus.WON.ToString());

        }

    }
}
