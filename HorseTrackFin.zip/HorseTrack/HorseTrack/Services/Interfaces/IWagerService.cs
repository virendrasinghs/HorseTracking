﻿using HorseTrack.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Services.Interfaces
{
    public interface IWagerService
    {
        int calculateAmountWon(int wager, int odds);
        List<Wager> dispenseWinnings(int winnings);


    }
}
