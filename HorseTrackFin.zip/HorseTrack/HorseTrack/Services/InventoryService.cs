﻿using HorseTrack.Model;
using HorseTrack.Repository;
using HorseTrack.Repository.Interfaces;
using HorseTrack.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Services
{
    public class InventoryService: IInventoryService
    {
        private IInventoryRepository inventoryRepository;

        public InventoryService(IInventoryRepository _inventoryRepository)
        {
            inventoryRepository = _inventoryRepository;
        }
        public void restock()
        {
            List<Inventory> inventories = inventoryRepository.findAll();

            foreach (var inventory in inventories)
            {
                inventory.setBillCount(Constant.restockAmount);
                inventoryRepository.save(inventory);
            }
        }

        public void decrementInventory(int denomination, int amount)
        {

            Inventory inventory = inventoryRepository.findByDenominationEquals(denomination);

            int currentBillCount = inventory.getBillCount();
            if ((currentBillCount - amount) >= 0)
            {
                inventory.setBillCount(currentBillCount - amount);
                inventoryRepository.save(inventory);
            }
        }

        public Boolean sufficientFunds(int amountWon)
        {

            List<Inventory> inventories = inventoryRepository.findAll();
            int result = 0;
            
            foreach (var inventory in inventories)
            {
                result = result + (inventory.getDenomination() * inventory.getBillCount());
            }
            
            if ((result - amountWon) >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<Inventory> getInventory()
        {
            return inventoryRepository.findAll();
        }

        public Inventory getInventory(int denomination)
        {
            return inventoryRepository.findByDenominationEquals(denomination);
        }

    }
}
