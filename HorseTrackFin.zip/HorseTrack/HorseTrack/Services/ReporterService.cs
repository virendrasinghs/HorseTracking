﻿using HorseTrack.Model;
using HorseTrack.Repository;
using HorseTrack.Repository.Interfaces;
using HorseTrack.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Services
{
    public class ReporterService : IReporterService
    {
        private readonly IHorseRepository horseRepository;

        private readonly IInventoryRepository inventoryRepository;

        public ReporterService(IHorseRepository _horseRepository, IInventoryRepository _inventoryRepository)
        {
            horseRepository = _horseRepository;
            inventoryRepository = _inventoryRepository;
        }

        public void printHorses()
        {

            List<Horse> horses = horseRepository.findAll();
            Console.WriteLine(Constant.messageHorses);
            foreach (var horse in horses)
            {
                Console.WriteLine(horse.getHorseNumber()
                    + "," + horse.getHorseName()
                    + "," + horse.getOdds()
                    + "," + horse.getRaceStatus().ToString().ToLower());
            }
        }

        public void printInventory()
        {
            List<Inventory> inventories = inventoryRepository.findAll();

            Console.WriteLine(Constant.messageInventory);
            foreach (var inventory in inventories)
            {
                Console.WriteLine(Constant.currencySymbol
                                    + inventory.getDenomination()
                                    + "," + inventory.getBillCount());
            }

        }

        public void printInvalidCommand(String command)
        {
            Console.WriteLine(Constant.errorMessageInvalidCommand + " " + command);
        }

        public void printInvalidHorse(int horseNumber)
        {
            Console.WriteLine(Constant.errorMessageInvalidHorseNumber + " " + horseNumber);
        }

        public void printInvalidBet(String invalidBet)
        {
            Console.WriteLine(Constant.errorMessageInvalidBet + " " + invalidBet);
        }

        public void printPayout(String horseName, int amountWon)
        {
            Console.WriteLine(Constant.messagePayout + " " + horseName + "," + Constant.currencySymbol + amountWon);
        }

        public void printNoPayout(String horseName)
        {
            Console.WriteLine(Constant.messageNoPayout + " " + horseName);
        }

        public void printInsufficientFunds(int amountWon)
        {
            Console.WriteLine(Constant.errorMessageInsufficientFunds + " " + Constant.currencySymbol + amountWon);
        }

        public void printDispense(List<Wager> dispense)
        {
            Console.WriteLine(Constant.messageDispensing);

            foreach (var wager in dispense)
            {
                Console.WriteLine(Constant.currencySymbol
                    + wager.getDenomination()
                    + ","
                    + wager.getBillCount()
                    );
            }
        }

        public void printErrorMessage(String message)
        {
            Console.WriteLine(message);
        }
        public void startup()
        {
            printInventory();
            printHorses();
        }

    }
}
