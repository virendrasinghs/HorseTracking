﻿using HorseTrack.Model;
using HorseTrack.Services.Interfaces;
using System;
using System.Collections.Generic;

namespace HorseTrack.Services
{
    public class WagerService: IWagerService
    {
        int ONE = 1;
        int FIVE = 5;
        int TEN = 10;
        int TWENTY = 20;
        int HUNDRED = 100;

        private readonly IInventoryService inventoryService;

        public WagerService(IInventoryService  _inventoryService)
        {
            inventoryService = _inventoryService;
        }
        public int calculateAmountWon(int wager, int odds)
        {
            return wager * odds;
        }

        public List<Wager> dispenseWinnings(int winnings)
        {

            List<Wager> wagerList = new List<Wager>();
            Wager wager;
            Boolean wagerAdded = false;

            List<Inventory> inventories = inventoryService.getInventory();
            List<int> denoms = new List<int>();
            foreach (var item in inventories)
            {
                denoms.Add(item.getDenomination());
            }

            denoms.Reverse();

            foreach (var denomination in denoms)
            {
                int bill = denomination;
                wagerAdded = false;
                for (int cnt = inventoryService.getInventory(bill).getBillCount(); cnt > 0; cnt--)
                {
                    int totalAmountOfBills = bill * cnt;
                    if (winnings >= totalAmountOfBills)
                    {
                        wager = new Wager(bill, cnt);
                        wagerList.Add(wager);
                        wagerAdded = true;
                        winnings -= totalAmountOfBills;
                        break;
                    }
                }
                if (!wagerAdded)
                {
                    wager = new Wager(bill, 0);
                    wagerList.Add(wager);
                }
            }

            foreach (var k in wagerList)
            {
                inventoryService.decrementInventory(k.getDenomination(), k.getBillCount());
            }

            return wagerList;
        }

    }
}
