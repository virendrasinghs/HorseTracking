﻿using HorseTrack.Database.Interfaces;
using HorseTrack.DataBusiness.Interfaces;
using HorseTrack.Services.Interfaces;
using System;

namespace HorseTrack.DataBusiness
{
    public class MainDataBusiness : IMainDataBusiness
    {
        private readonly IConfigService configService;
        private Boolean bquit = false;
        private readonly IHorseService horseService;
        private readonly IInventoryService inventoryService;
        private readonly ICommandService commandService;
        private readonly IReporterService reporterService;
        private readonly IWagerService wagerService;
        private readonly IHorseTrackDatabase horseTrackDatabase;
        public MainDataBusiness(IConfigService _configService, IHorseService _horseService,
            IInventoryService _inventoryService,ICommandService _commandService,IReporterService _reporterService,
            IWagerService _wagerService,IHorseTrackDatabase _horseTrackDatabase)
        {
            configService = _configService;
            horseService = _horseService;
            inventoryService = _inventoryService;
            commandService = _commandService;
            reporterService = _reporterService;
            wagerService = _wagerService;
            horseTrackDatabase = _horseTrackDatabase;
        }


        public void execute(String commandLine)
        {
            Console.WriteLine("Command issued: " + commandLine);
            if (commandLine.Length > 0)
            {
                if ((commandService.parseCommand(commandLine).Contains("invalid", StringComparison.OrdinalIgnoreCase)))
                {
                    reporterService.printInvalidCommand(commandLine);
                }
                else
                {
                    commandFactory(commandLine);
                }
            }
        }

        public void commandFactory(String commandLine)
        {
            String command = commandService.parseCommand(commandLine);

            switch (command)
            {
                case "quit":
                    bquit = true;
                    break;
                case "restock":
                    restock();
                    break;
                case "winner":
                    winner(commandService.getWinningHorseNumber());
                    break;
                case "wager":
                    wager(commandService.getBetHorseNumber(), commandService.getWagerAmount());
                    break;
                case "error":
                    reporterService.printErrorMessage(commandService.getErrorMessage());
                    break;
                default:
                    break;
                    // Do nothing
            }
        }

        public Boolean quit()
        {
            return bquit;
        }

        public void restock()
        {
            inventoryService.restock();
            reporterService.printInventory();
        }

        public void wager(int horseNumber, int wagerAmount)
        {
            if (!(horseService.isValidHorseNumber(horseNumber)))
            {
                reporterService.printInvalidHorse(horseNumber);
                return;
            }

            if (!(horseService.isHorseWinner(horseNumber)))
            {
                reporterService.printNoPayout(horseService.getHorseName(horseNumber));
                return;
            }

            int amountWon = wagerService.calculateAmountWon(
                wagerAmount,
                horseService.getHorseOdds(horseNumber));
            if (inventoryService.sufficientFunds(amountWon))
            {
                reporterService.printPayout(horseService.getHorseName(horseNumber), amountWon);
                reporterService.printDispense(wagerService.dispenseWinnings(amountWon));
            }
            else
            {
                reporterService.printInsufficientFunds(amountWon);
            }

            reporterService.printInventory();
            reporterService.printHorses();
        } 

        public void winner(int horseNumber)
        {
            if (horseService.isValidHorseNumber(horseNumber))
            {
                horseService.setRaceWinner(horseNumber);
                reporterService.printInventory();
                reporterService.printHorses();
            }
            else
            {
                reporterService.printInvalidHorse(horseNumber);
            }
        }

        public void printStartupMessages()
        {
            reporterService.startup();
        }

        public void initialize()
        {
            horseTrackDatabase.TruncateHorse();
            horseTrackDatabase.TruncateInventory();
            configService.Initilize();
        }

    }

}

