﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Enum
{
 
    public enum RaceStatus
    {
        WON,
        LOST
    }

}
