﻿using HorseTrack.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Model
{
    public class Horse
    {
        public Horse()
        {
        }

        public Horse(int horseNumber, String horseName, int odds, RaceStatus raceStatus)
        {
            this.horseNumber = horseNumber;
            this.horseName = horseName;
            this.odds = odds;
            this.raceStatus = raceStatus;
        }

        private int id;

        private int horseNumber;

        private String horseName;

        private int odds;

        private RaceStatus raceStatus = RaceStatus.LOST;

        public int getId()
        {
            return id;
        }

        public void setId(int id)
        {
            this.id = id;
        }

        public int getHorseNumber()
        {
            return horseNumber;
        }

        public void setHorseNumber(int horseNumber)
        {
            this.horseNumber = horseNumber;
        }

        public String getHorseName()
        {
            return horseName;
        }

        public void setHorseName(String horseName)
        {
            this.horseName = horseName;
        }

        public int getOdds()
        {
            return odds;
        }

        public void setOdds(int odds)
        {
            this.odds = odds;
        }

        public RaceStatus getRaceStatus()
        {
            return raceStatus;
        }

        public void setRaceStatus(RaceStatus raceStatus)
        {
            this.raceStatus = raceStatus;
        }

        public String toString()
        {
            StringBuilder sb = new StringBuilder("Horse{");
            sb.Append("id=").Append(id);
            sb.Append(", horseNumber=").Append(horseNumber);
            sb.Append(", horseName='").Append(horseName).Append('\'');
            sb.Append(", odds=").Append(odds);
            sb.Append(", raceStatus=").Append(raceStatus);
            sb.Append('}');
            return sb.ToString();
        }
    }

}

