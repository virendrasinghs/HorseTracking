﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Model
{
    public class Wager
    {

        private int denomination;
        private int billCount;

        public Wager(int denomination, int billCount)
        {
            this.denomination = denomination;
            this.billCount = billCount;
        }

        public int getDenomination()
        {
            return denomination;
        }

        public int getBillCount()
        {
            return billCount;
        }

        public String toString()
        {
            StringBuilder sb = new StringBuilder("Wager{");
            sb.Append("denomination=").Append(denomination);
            sb.Append(", billCount=").Append(billCount);
            sb.Append('}');
            return sb.ToString();
        }
    }
}

