﻿using HorseTrack.Model;
using System;
using System.Collections.Generic;
using System.Text;
using HorseTrack.Database;
using HorseTrack.Database.Interfaces;
using HorseTrack.Repository.Interfaces;

namespace HorseTrack.Repository
{
    public class HorseRepository: IHorseRepository
    {
        private readonly IHorseTrackDatabase database;
        public HorseRepository(IHorseTrackDatabase horseTrackDatabase) {
            database = horseTrackDatabase;
        }
        public bool save(Horse horse)
        {
            return database.InsertHorse(horse);
        }
        public Boolean UpdateHorseRaceStatus(int horseNumber, string raceStatus)
        {
            try
            {
                return database.UpdateHorseRaceStatus(horseNumber, raceStatus);
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public Horse findByHorseNumberEquals(int horseNumber)
        {
            return database.findByHorseNumberEquals(horseNumber);
        }
        public List<Horse> findAll()
        {
            return database.findAllHorse();
        }
        

    }
}
