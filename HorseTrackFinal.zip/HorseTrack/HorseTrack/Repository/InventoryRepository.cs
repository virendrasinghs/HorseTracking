﻿using HorseTrack.Database.Interfaces;
using HorseTrack.Model;
using HorseTrack.Repository.Interfaces;
using System.Collections.Generic;

namespace HorseTrack.Repository
{
    public class InventoryRepository: IInventoryRepository
    {
        private readonly IHorseTrackDatabase database;
        public InventoryRepository(IHorseTrackDatabase horseTrackDatabase)
        {
            database = horseTrackDatabase;
        }
        public bool save(Inventory inventory)
        {
            return database.InsertInventory(inventory);
        }

        public bool InventoryUpdate(int id, int billCount)
        {
            return database.InventoryUpdate(id, billCount);
        }

        public List<Inventory> findAll()
        {
            return database.findAllInventory();
        }

        public Inventory findByDenominationEquals(int denomination)
        {
            return database.findByDenominationEquals(denomination);
        }
        


    }
}
