﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HorseTrack.Services.Interfaces
{
    public interface IHorseService
    {
        String getHorseName(int horseNumber);
        int getHorseOdds(int horseNumber);
        Boolean isHorseWinner(int horseNumber);
        Boolean isValidHorseNumber(int horseNumber);
        void setRaceWinner(int horseNumber);
    }
}
